clear
[segs, classes] = speakerDiarization('diarizationExample.wav', 4);

segmentationPlotResults(segs, classes, 'diarizationExample.wav')

