[segs, classes, Labels, centers] = silenceRemoval('3WORDS.WAV', 0, 0);

segmentationPlotResults(segs, classes, '3WORDS.WAV')