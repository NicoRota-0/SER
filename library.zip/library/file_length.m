% This module returns the length of an audio file
function len = file_length(f)
    f = join([pwd, '/dataset/', f], '');
    f_str = string(f);
    [y,fs]=audioread(f_str);
    len=max(size(y)/fs);
end